import Foundation

public struct Bread {
    public enum BreadType: UInt32 {
        case small = 1
        case medium
        case big
    }
    
    public let breadType: BreadType
    
    public static func make() -> Bread {
        guard let breadType = Bread.BreadType(rawValue: UInt32(arc4random_uniform(3) + 1)) else {
            fatalError("Incorrect random value")
        }
        return Bread(breadType: breadType)
    }
    
    public func bake() {
        let bakeTime = breadType.rawValue
        sleep(UInt32(bakeTime))
    }
}



class BreadStorage {
    
    var available = false
    let mutex = NSCondition()
    
    private var storage: [Bread] = []
    
    public func numberSt() -> Int { return storage.count}
    
    public func putBread(bread: Bread) {
        mutex.lock()
        available = true
        storage.append(bread)
        print("MakeBread")
        mutex.signal()
        mutex.unlock()
    }
    
    public func popBread() -> Bread? {
        mutex.lock()
        while !available {
            mutex.wait()
        }
        guard !storage.isEmpty else {
            mutex.unlock()
            print("No Bread")
            return nil }
        
        let returnBread = storage.removeLast()
        print("BakeBread")
        
        available = false
        mutex.unlock()
        return returnBread
    }
}

class GenericThread: Thread {
    // Генерирующий поток использует таймер, с интервалом 2 сеекунды, создает хлеб и добавляет на склад
    private let breadStorage: BreadStorage
    private var timer: Timer!
    
    init(storage: BreadStorage) {
           breadStorage = storage
           super.init()
    }
    
    override func main() {
        timer = Timer.init(timeInterval: 2.0, target: self, selector: #selector(makeBread), userInfo: nil, repeats: true)
        RunLoop.current.add(timer, forMode: .default)
        RunLoop.current.run()
        
    }
    @objc private func makeBread() {
        guard isCancelled == false else {
            //Нужно, чтоб остановить таймер иначе этот метод будет вызываться бессконечно
            timer.invalidate()
           return }
       breadStorage.putBread(bread: Bread.make())
    }
}

let storage = BreadStorage()
let genericThread = GenericThread(storage: storage)

class WorkTread: Thread {
    private let breadStorage: BreadStorage
    
    init(storage: BreadStorage) {
        breadStorage = storage
        super.init()
    }
    override func main() {
        //Проверка в цикле: 1) Работает ли Генерирующий поток; 2) Есть ли хлеб в хранилище.
        let storageCount = breadStorage.numberSt()
        while !genericThread.isCancelled || storageCount != 0 {
            breadStorage.popBread()
        }
    }
}

let workThread = WorkTread(storage: storage)

genericThread.start()
workThread.start()
sleep(10)
genericThread.cancel()
workThread.cancel()


